package edu.wpi.cs.t15.demo.model;

import java.util.LinkedList;

public class Task {
	private String name; 
	private int userID; 
	private int taskID; 
	private int projectID; 
	private boolean status; 
	private boolean isSubtask; 
	private LinkedList<Task> subtasks; 
	
	public Task(String name, int userID, int projectID, boolean isSubtask) {
		this.name = name; 
		this.taskID = 0; //TODO
		this.projectID = projectID; 
		this.status = false; 
		this.isSubtask = isSubtask; 
		this.subtasks = new LinkedList<Task>(); 
		this.userID = userID; 
	}
	
	public String getName() {
		return name;
	}
	
	public int getUserID() {
		return userID; 
	}
	
	public int getTaskID() {
		return taskID;
	}
	
	public int getProjectID() {
		return projectID;
	}

	public boolean getIsSubtask() {
		return isSubtask;
	}
}
