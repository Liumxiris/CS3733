package edu.wpi.cs.t15.demo.model;

import java.util.LinkedList;

public class User {
	private String name; 
	private int userID; 
	private int teamID;
	private LinkedList<Task> tasks; 
	
	public User(String name, int teamID) {
		this.name = name; 
		this.userID = 0; //TODO
		this.teamID = teamID; 
		this.tasks = new LinkedList<Task>(); 
	}
	
	public String getName() {
		return name;
	}
	
	public int getUserID() {
		return userID;
	}

	public int getTeamID() {
		return teamID;
	}
}
