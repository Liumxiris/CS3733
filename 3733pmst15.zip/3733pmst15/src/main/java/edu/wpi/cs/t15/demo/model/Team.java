package edu.wpi.cs.t15.demo.model;

import java.util.LinkedList;

public class Team {
	private String name; 
	private int teamID; 
	private int projectID; 
	private LinkedList<User> users; 
	
	public Team(String name, int projectID) {
		this.name = name; 
		this.teamID = 0; //TODO
		this.projectID = projectID; 
		this.users = new LinkedList<User>(); 
	}
	
	public String getName() {
		return name;
	}
	
	public int getTeamID() {
		return teamID;
	}
	
	public int getProjectID() {
		return projectID;
	}

}
