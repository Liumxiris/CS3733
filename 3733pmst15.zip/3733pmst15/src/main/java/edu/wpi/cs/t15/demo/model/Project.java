package edu.wpi.cs.t15.demo.model;

import java.util.LinkedList;

public class Project {
	private String title; 
	private LinkedList<Task> tasks; 
	private LinkedList<User> users; 
	private int projectID; 
	private int status; 
	private boolean isArchived; 
	
	public Project(String title) {
		this.title = title; 
		this.projectID = 0; //TODO
		this.tasks = new LinkedList<Task>(); 
		this.users = new LinkedList<User>(); 
		this.isArchived = false; 
		this.status = 0; 
	}
	
	public String getTitle() {
		return title; 
	}
	
//	public int getProjID() {
//		return projectID; 
//	}

}
